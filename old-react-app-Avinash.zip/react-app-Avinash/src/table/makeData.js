export const DATA = [
    {
        firstName: 'first name 1',
        lastName: 'last name 1',
        age: '28'
    },
    {
        firstName: 'first name 2',
        lastName: 'last name 3',
        age: '28'
    },
];