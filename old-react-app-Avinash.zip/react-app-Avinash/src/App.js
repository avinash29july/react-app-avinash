import AddComponent from './add/AddComponent';
import './App.css';

function App() {
  return (
    <div className="App">
      <AddComponent />
    </div>
  );
}

export default App;
